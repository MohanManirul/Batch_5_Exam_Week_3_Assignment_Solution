<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><img src="/images/<?php echo e($product->image); ?>" width="100px"></td>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->detail); ?></td>
        <td>
            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                <a class="btn btn-info btn-sm" href="<?php echo e(route('products.show', $product->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('products.edit', $product->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
            </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\examWeekb5\resources\views/products/partials/product_rows.blade.php ENDPATH**/ ?>