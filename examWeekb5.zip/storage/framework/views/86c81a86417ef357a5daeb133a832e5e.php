     
<?php $__env->startSection('content'); ?>
<div class="card mt-5">
  <h2 class="card-header text-center">Laravel 11 CRUD with Image Upload Ostad</h2>
  <div class="card-body">
           
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="alert alert-success" role="alert"> <?php echo e($value); ?> </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

        <div class="mb-3">
            <input type="text" id="search" class="form-control" placeholder="Search products...">
        </div>

        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <a class="btn btn-success btn-sm" href="<?php echo e(route('products.create')); ?>"> <i class="fa fa-plus"></i> Create New Product</a>
        </div>
   
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th width="80px">No</th>
                    <th>Image</th>
                    <th>
                        <a href="<?php echo e(route('products.index', ['sortBy' => 'name', 'sort' => request('sort') == 'asc' ? 'desc' : 'asc'])); ?>">
                            Name
                            <i class="fa <?php echo e(request('sortBy') == 'name' && request('sort') == 'asc' ? 'fa-arrow-up' : 'fa-arrow-down'); ?>"></i>
                        </a>
                    </th>
                    <th>
                        <a href="<?php echo e(route('products.index', ['sortBy' => 'detail', 'sort' => request('sort') == 'asc' ? 'desc' : 'asc'])); ?>">
                            Details
                            <i class="fa <?php echo e(request('sortBy') == 'detail' && request('sort') == 'asc' ? 'fa-arrow-up' : 'fa-arrow-down'); ?>"></i>
                        </a>
                    </th>
                    <th width="250px">Action</th>
                </tr>
            </thead>
             
  
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><img src="/images/<?php echo e($product->image); ?>" width="100px"></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->detail); ?></td>
                        <td>
                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                                
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('products.show', $product->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>

                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('products.edit', $product->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                                
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            </tbody>
  
        </table>
        
        <?php echo $products->withQueryString()->links('pagination::bootstrap-5'); ?>

  
  </div>
</div>  



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
 
// you can also use keyup 
    $(document).ready(function() {
        $('#search').on('input', function() {
           debugger;
            let query = $(this).val();
          
            $.ajax({
                url: "<?php echo e(route('products.search')); ?>",
                type: 'GET',
                data: { 'query': query },
                success: function(data) {
                    $('tbody').html(data); // Update only the tbody with new rows
                },
                error: function() {
                    alert('Search failed. Please try again.');
                }
            });

        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examWeekb5\resources\views/products/index.blade.php ENDPATH**/ ?>